# 🎓 VNRVJIET AI - Intelligent College Website Knowledge Assistant

An AI-powered web intelligence system that automatically scrapes, understands, and answers queries from college websites including all linked PDF documents. Features a persistent knowledge base for reliable information retrieval.

[![Python](https://img.shields.io/badge/Python-3.9+-3776AB?logo=python&logoColor=white)](https://python.org)
[![React](https://img.shields.io/badge/React-19+-61DAFB?logo=react&logoColor=black)](https://react.dev)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.109+-009688?logo=fastapi&logoColor=white)](https://fastapi.tiangolo.com)
[![ChromaDB](https://img.shields.io/badge/VectorDB-ChromaDB-orange)](https://www.trychroma.com/)

---

## 🧠 Product Overview

VNRVJIET AI is a **Retrieval-Augmented Generation (RAG)** system designed to act as an intelligent layer over college websites. It processes structured and unstructured data (HTML and PDFs) to provide grounded, citation-backed answers.

- **Persistent Knowledge**: Uses ChromaDB to ensure the knowledge base survives restarts.
- **Deep Scrape**: Automatically discovers and extracts text from linked PDF documents.
- **Source-Grounded**: Every AI response includes direct links to the official data sources.
- **Admin Control**: Built-in dashboard for monitoring indexing status and system health.

---

## 🏗️ Architecture

| Layer | Technology | Description |
|-------|------------|-------------|
| **Frontend** | React 19 + Vite | Fast, responsive chat interface and admin panel |
| **Backend** | Python FastAPI | High-performance asynchronous API layer |
| **Scraper** | Firecrawl / BS4 | Advanced web crawling and extraction |
| **PDF Processor** | PyMuPDF | Robust text extraction from official college PDFs |
| **Embeddings** | `BAAI/bge-base-en-v1.5` | Top-tier semantic vector encoding |
| **Vector DB** | ChromaDB | Persistent local storage for indexed content |
| **LLM** | Google Gemini 2.0 Flash | State-of-the-art grounded answer generation |

---

## 📁 Project Structure

```text
ai-chat/
├── Backend/
│   ├── app.py                 # Main API application
│   ├── modules/               # Core RAG, Scraper, and Processor logic
│   ├── storage/               # Persistent ChromaDB files (Git ignored)
│   ├── data/                  # Raw scraped HTML and PDFs
│   └── requirements.txt       # Python dependencies
├── frontend/                  # React Application
│   ├── src/components/        # Chat and Admin UI components
│   ├── src/services/          # API integration layer
│   └── index.html             # Entry point
├── .gitignore                 # Unified ignore rules
└── README.md                  # Comprehensive documentation
```

---

## 🚀 Local Development

### 1. Prerequisites
- Python 3.9+
- Node.js 18+
- [Firecrawl API Key](https://firecrawl.dev)
- [Google Gemini API Key](https://aistudio.google.com)

### 2. Configure Environment
Create a `.env` file in the `Backend/` directory:
```env
FIRECRAWL_API_KEY=your_firecrawl_key
GEMINI_API_KEY=your_gemini_key
```

### 3. Backend Setup
```bash
cd Backend
python -m venv venv
# Windows
venv\Scripts\activate
# Unix/macOS
source venv/bin/activate

pip install -r requirements.txt
python app.py
```

### 4. Frontend Setup
```bash
cd frontend
npm install
npm run dev
```

---

## 🛠️ Deployment Guide

### Backend (Railway / Render)
1. Fork this repository.
2. Link your GitHub account to the deployment platform.
3. **Environment Variables**: Add `FIRECRAWL_API_KEY` and `GEMINI_API_KEY`.
4. **Persistent Volume**: Ensure `Backend/storage` is mounted to a persistent disk to preserve the ChromaDB index.
5. **Build Command**: `pip install -r requirements.txt`
6. **Start Command**: `python app.py` (or `uvicorn app:app --host 0.0.0.0 --port $PORT`)

### Frontend (Vercel / Netlify)
1. Deploy the `frontend/` subdirectory.
2. **Environment Variable**: Set `VITE_API_URL` to your Backend's public URL.
3. **Build Command**: `npm run build`
4. **Output Directory**: `dist`

---

## 📖 Features

- **Topic-Aware RAG**: Specialized handling for faculty, syllabus, and placement queries.
- **Real-time Status**: Admin panel shows exactly how many pages are indexed.
- **Interactive Citations**: Clickable links in chat bubbles for instant verification.

---

## 🤝 Contributing

1. Fork the Project.
2. Create your Feature Branch (`git checkout -b feature/AmazingFeature`).
3. Commit your Changes (`git commit -m 'Add some AmazingFeature'`).
4. Push to the Branch (`git push origin feature/AmazingFeature`).
5. Open a Pull Request.


---
Built for the VNRVJIET Community • Powered by RAG & ChromaDB
