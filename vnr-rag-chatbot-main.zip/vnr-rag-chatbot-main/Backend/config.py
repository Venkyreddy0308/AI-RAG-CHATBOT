
import os
import sys
from pathlib import Path
if sys.stdout and sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
STORAGE_DIR = BASE_DIR / "storage"
PDF_DIR = DATA_DIR / "pdfs"

DATA_DIR.mkdir(exist_ok=True)
STORAGE_DIR.mkdir(exist_ok=True)
PDF_DIR.mkdir(exist_ok=True)
VECTOR_STORE_DIR = STORAGE_DIR

SCRAPE_CONFIG = {
    "max_pages": 500,           
    "max_depth": 5,             
    "timeout": 30,              
    "delay": 0.5,               
    "user_agent": "VNRVJIET AI Bot/1.0",
    "allowed_extensions": [".html", ".htm", ".php", ".asp", ".aspx", ""],
    "pdf_extensions": [".pdf"],
}

PDF_CONFIG = {
    "max_file_size_mb": 50,     
    "chunk_size": 500,          
    "chunk_overlap": 100,       
}

EMBEDDING_CONFIG = {
    "model_name": "BAAI/bge-base-en-v1.5",  
    "dimension": 768,                         
    "batch_size": 32,                         
}

CSE_SUB_DEPT_KEYWORDS = {
    'CSE-DS': ['cse-ds', 'cse ds', 'data science', 'ds department'],
    'CSE-CYS': ['cys', 'cyber security', 'cybersecurity', 'cse-cys'],
    'CSE-AIML': ['aiml', 'ai & ml', 'ai and ml', 'cse-aiml', 'artificial intelligence and machine learning'],
    'CSE-IOT': ['iot', 'internet of things', 'cse-iot'],
}

CSE_DEPT_KEYWORDS = [
    'cse', 'computer science', 'c.s.e', 'department of computer science',
    'b.tech cse', 'cse syllabus', 'cse lab', 'cse faculty',
]

CSE_QUERY_KEYWORDS = [
    'cse', 'computer science', 'c.s.e', 'data structures', 'algorithms',
    'software engineering', 'dbms', 'operating systems', 'os',
    'computer networks', 'compiler design', 'machine learning',
    'cse syllabus', 'cse faculty', 'c d naidu', 'manmath nath das',
]

GENERAL_KEYWORDS = [
    'hostel', 'fee', 'admission', 'principal', 'chairman', 'placement',
    'contact', 'address', 'transport', 'governance', 'leadership', 'director',
]
OTHER_BRANCH_KEYWORDS = [
    'ece', 'mechanical', 'civil', 'eee', 'it', 'electronics', 'electrical',
    'ae', 'automobile', 'engineering',
]

RAG_CONFIG = {
    "top_k": 3,                   
    "min_similarity": 0.6,      
    "max_context_length": 15000, 
}

LLM_CONFIG = {
    "gemini_model": "gemini-2.0-flash",

    "openrouter_model": "mistralai/mistral-7b-instruct",
    "openrouter_fallback": "upstage/solar-pro-3:free",

    "hf_model": "meta-llama/Meta-Llama-3-8B-Instruct",
    "hf_fallback": "mistralai/Mistral-7B-Instruct-v0.3",

    "ollama_model": "qwen2.5:1.5b",

    "temperature": 0.1,   
    "max_tokens": 1024,   
    "enabled": True,
}

FIRECRAWL_CONFIG = {
    "max_pages": 100,              
    "include_formats": ["markdown", "html"],
    "exclude_tags": ["nav", "footer", "header", "aside", "script", "style"],
}

DEFAULT_TARGET_URL = "https://vnrvjiet.ac.in/"  
