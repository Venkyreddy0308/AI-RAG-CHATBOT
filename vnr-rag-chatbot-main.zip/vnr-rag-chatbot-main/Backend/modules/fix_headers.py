import re
import os

file_path = r'c:\VNRVJIET\Projects\ai-chat\Backend\cleaned_pages\PDF_CSE_R22_III_Year.md'

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

content = re.sub(r'\*\*COURSE OBJECTIVES:?\s*\*\*', '#### COURSE OBJECTIVES', content, flags=re.IGNORECASE)
content = re.sub(r'\*\*COURSE OUTCOMES:?\s*\*\*', '#### COURSE OUTCOMES', content, flags=re.IGNORECASE)
content = re.sub(r'\*\*SYLLABUS\*\*', '#### SYLLABUS', content, flags=re.IGNORECASE)
content = re.sub(r'\*\*TEXT\s*BOOKS:?\s*\*\*', '#### TEXT BOOKS', content, flags=re.IGNORECASE)
content = re.sub(r'\*\*REFERENCES:?\s*\*\*', '#### REFERENCES', content, flags=re.IGNORECASE)
content = re.sub(r'\*\*WEB\s*RESOURCES:?\s*\*\*', '#### WEB RESOURCES', content, flags=re.IGNORECASE)

 
def replace_unit_header(match):
    unit_num = match.group(1)
    title = match.group(2).strip()
    return f'#### UNIT-{unit_num}\n**{title}**:'


content = re.sub(r'\*\*UNIT-([IVX]+)[:\s]+(.*?)\*\*', replace_unit_header, content)

content = re.sub(r'#{4}\s*UNIT-([IVX]+)[:\s]+(.*?)$', replace_unit_header, content, flags=re.MULTILINE)



with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Headers standardized successfully.")
