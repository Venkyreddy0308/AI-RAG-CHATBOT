import re
from typing import Optional, List, Dict, Set
from collections import Counter


_noise_lines: Set[str] = set()


def build_noise_lines(pages: List[Dict]) -> Set[str]:

    global _noise_lines
    
    counter = Counter()
    
    for page in pages:
        md = page.get("markdown", "") or page.get("content", "") or ""
        for line in md.split("\n"):
            line = line.strip()
            
            if len(line) > 30:
                counter[line] += 1
    
    noise = set()
    threshold = max(15, len(pages) // 10)  
    
    for line, count in counter.items():
        if count > threshold:
            noise.add(line)
    
    _noise_lines = noise
    return noise


def get_noise_lines() -> Set[str]:
    return _noise_lines


def clean_markdown(md: str, noise_lines: Optional[Set[str]] = None) -> str:

    import re
    
    if not md:
        return ""
    
    if noise_lines is None:
        noise_lines = _noise_lines
    
    cleaned = []
    
    nav_patterns = [
        r'^-\s*\[.*?\]\(.*?#.*?\)$',  
        r'^-\s*\[Notifications\]',     
        r'^-\s*\[Home\]',              
        r'^-\s*\[Administration\]',    
        r'^-\s*\[Academics\]',         
        r'^-\s*\[Campus\]',            
        r'^-\s*\[Campus Life\]',       
        r'^\[\!\[.*?\]\(.*?\)\]\(.*?\)$',  
        r'^!\[.*?\]\(.*?\)$',          
        r'^-\s*$',                      
        r'^#+\s*$',                     
        r'^Close$',                     
        r'^Menu$',                      
        r'^close$',
        r'^\|[\s\-\|]+\|$',            
    ]
    
    for line in md.split("\n"):
        line_stripped = line.strip()
        
        if not line_stripped:
            continue
        
        if line_stripped in noise_lines:
            continue
        
        skip_line = False
        for pattern in nav_patterns:
            if re.match(pattern, line_stripped, re.IGNORECASE):
                skip_line = True
                break
        if skip_line:
            continue
        
        is_header = line_stripped.startswith('#')
        is_table_row = '|' in line_stripped and len(line_stripped) > 10
        is_meaningful_list = line_stripped.startswith('-') and len(line_stripped) > 50
        
        if len(line_stripped) < 40 and not is_header and not is_table_row and not is_meaningful_list:
            continue
        
        link_only_match = re.match(r'^\[([^\]]*)\]\([^\)]+\)$', line_stripped)
        if link_only_match:
            link_text = link_only_match.group(1)
            if len(link_text) < 30 and not link_text.startswith('Click'):
                continue
        
        cleaned.append(line)
    
    result = "\n".join(cleaned)
    
    result = re.sub(r'\n{3,}', '\n\n', result)
    
    return result.strip()


def clean_webpage_text(text: str, noise_lines: Optional[Set[str]] = None) -> str:
    
    if not text:
        return ""
    
    if noise_lines or _noise_lines:
        text = clean_markdown(text, noise_lines)
    
    text = re.sub(r'\s+', ' ', text)
    
    garbage_patterns = [
        r'©.*?VNRVJIET',
        r'©.*?VNR VJIET',
        r'All rights reserved.*?$',
        r'Copyright.*?VNRVJIET',
        
        r'\b(facebook|twitter|instagram|linkedin|youtube)\b',
        
        r'Skip to (main )?content',
        r'Toggle navigation',
        r'\[\s*\]\s*\([^)]+\)',
    ]
    
    for pattern in garbage_patterns:
        text = re.sub(pattern, ' ', text, flags=re.IGNORECASE)
    
    lines = text.split('.')
    cleaned_lines = []
    
    for line in lines:
        line = line.strip()
        
        if not line:
            continue
        
        link_count = len(re.findall(r'http|www|\.ac\.in|\.pdf|#\w+', line, re.IGNORECASE))
        if link_count > 3:
            continue
        
        if len(line) < 30:
            continue
        
        cleaned_lines.append(line)
    
    result = '. '.join(cleaned_lines)
    
    result = re.sub(r'\s+', ' ', result).strip()
    result = re.sub(r'\.+', '.', result)  
    result = re.sub(r'\s+\.', '.', result)  
    
    return result


def clean_pdf_text(text: str) -> str:

    if not text:
        return ""
    
    text = re.sub(r'Page\s*\d+\s*(of\s*\d+)?', '', text, flags=re.IGNORECASE)
    
    text = re.sub(r'\s+', ' ', text)
    
    text = re.sub(r'-\s*\n\s*', '', text)  
    
    return text.strip()


if __name__ == "__main__":
    
    test_pages = [
        {"markdown": """
Departments Automobile Engineering Chemistry Civil Engineering Computer Science
VNR VJIET is one of the premier engineering institutions in Telangana.
The college offers undergraduate and postgraduate programs in various disciplines.
Professional Chapters ACM ASME CSI IEEE ISTE SAE
Campus Celebrations Annual Day Convergence Cultural Day
© 2024 VNRVJIET. All rights reserved.
"""},
        {"markdown": """
Departments Automobile Engineering Chemistry Civil Engineering Computer Science
The Electronics department has state-of-the-art laboratories and equipment.
Faculty members have published over 500 research papers in international journals.
Professional Chapters ACM ASME CSI IEEE ISTE SAE
Campus Celebrations Annual Day Convergence Cultural Day
© 2024 VNRVJIET. All rights reserved.
"""},
        {"markdown": """
Departments Automobile Engineering Chemistry Civil Engineering Computer Science
Our placement cell has achieved 95% placement rate for the 2024 batch.
Top recruiters include Google, Microsoft, Amazon, and TCS.
Professional Chapters ACM ASME CSI IEEE ISTE SAE
Campus Celebrations Annual Day Convergence Cultural Day
© 2024 VNRVJIET. All rights reserved.
"""},
    ] * 10   
    
    print("=" * 60)
    print("REPETITION-BASED NOISE DETECTION TEST")
    print("=" * 60)
    
    noise_lines = build_noise_lines(test_pages)
    print(f"\n1. Found {len(noise_lines)} noise lines that appear across pages:")
    for line in sorted(noise_lines)[:5]:
        print(f"   - '{line[:60]}...'")
    
    test_page = test_pages[0]["markdown"]
    cleaned = clean_markdown(test_page, noise_lines)
    
    print(f"\n2. Original page ({len(test_page)} chars):")
    print(test_page[:200])
    
    print(f"\n3. Cleaned page ({len(cleaned)} chars):")
    print(cleaned if cleaned else "   (All content was identified as boilerplate)")
    
    print("\n" + "=" * 60)
    print("The key insight: Lines like 'Departments Automobile Engineering...'")
    print("are NOW removed because they appear in 30 pages, not because of regex!")
    print("=" * 60)
