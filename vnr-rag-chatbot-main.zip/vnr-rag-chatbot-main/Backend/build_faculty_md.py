import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from config import DATA_DIR, PDF_DIR
from modules.embeddings import KnowledgeIndex

from extract_faculty import main as extract_faculty_main


def build_faculty_md(delete_pdfs: bool = False):
    """
    Step 1: Extract faculty data from PDFs → faculty.md
    """
    print("=" * 60)
    print("STEP 1: Extracting Faculty Data from PDFs")
    print("=" * 60)
    
    extract_faculty_main(delete_pdfs=delete_pdfs)
    
    faculty_file = Path(__file__).parent / 'cleaned_pages' / 'faculty.md'
    if faculty_file.exists():
        print(f"\n[OK] faculty.md created at: {faculty_file}")
        return True
    else:
        print("\n[WARN] faculty.md was not created (no faculty PDFs found?)")
        return False


def reindex_with_faculty():
    print("\n" + "=" * 60)
    print("STEP 2: Adding Faculty Data to ChromaDB Index")
    print("=" * 60)
    
    faculty_file = Path(__file__).parent / 'cleaned_pages' / 'faculty.md'
    if not faculty_file.exists():
        print(f"[ERROR] {faculty_file} not found.")
        return False
    
    index = KnowledgeIndex()
    
    try:
        total = index.collection.count()
    except Exception:
        total = 0

    if total == 0:
        print("[WARN] No existing index found. Run full indexing first.")
        return False
    
    print(f"[INFO] Existing ChromaDB index has {total} chunks")
    
    print("[*] Adding faculty.md to ChromaDB...")
    added = index.add_markdown_file(faculty_file, "Faculty Directory")
    
    if added > 0:
        new_total = index.collection.count()
        print(f"[OK] Added {added} faculty chunks to ChromaDB")
        print(f"[OK] Index now has {new_total} total chunks")
        return True
    else:
        print("[WARN] No faculty chunks added")
        return False


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Build faculty.md from PDFs")
    parser.add_argument('--reindex', action='store_true', 
                       help='Also add faculty.md to existing index')
    parser.add_argument('--delete-pdfs', action='store_true',
                       help='Delete faculty PDFs after extraction')
    
    args = parser.parse_args()
    
    print("\n" + "=" * 60)
    print("Build Faculty MD - Post-Indexing PDF Processor")
    print("=" * 60)
    print(f"PDF Directory: {PDF_DIR}")
    faculty_path = Path(__file__).parent / 'cleaned_pages' / 'faculty.md'
    print(f"Faculty Source: {faculty_path}")
    print("=" * 60 + "\n")
    
    success = build_faculty_md(delete_pdfs=args.delete_pdfs)
    
    if success and args.reindex:
        reindex_with_faculty()
    elif success:
        print("\n[TIP] Run with --reindex to add faculty.md to the search index")
    
    print("\n" + "=" * 60)
    print("COMPLETE")
    print("=" * 60)


if __name__ == "__main__":
    main()
